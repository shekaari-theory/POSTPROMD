#!/bin/bash
# Copyright (C) 2024 Ashkan Shekaari/POST-PROMD.
# This file has been distributed under the terms of
# GNU General Public License (Version 3, 29 June 2007). 
# PLEASE, take a look at the file 'License'
# in the root directory of the present distribution,
# or visit https://www.gnu.org/licenses/gpl-3.0.txt .
# For details: Please, take a look at 'README' file.
cp par.input par2.dat
cat rdf.source >> par2.dat
mv par2.dat make_rdf.sh
bash make_rdf.sh
rm make_rdf.sh

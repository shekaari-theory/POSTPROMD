Copyright (C) 2024 Ashkan Shekaari/POST-PROMD. This file has been distributed under the terms of GNU General Public License (Version 3, 29 June 2007). PLEASE, take a look at the file 'License' in the root directory of the present distribution, or visit https://www.gnu.org/licenses/gpl-3.0.txt. For details: Please, take a look at 'README' file.

This example simulates molecular dynamics of the unit cell of SLSiN (single-layer Si$_3$N$_4$), containing 14 atoms, using Car-Parrinello approach, at T = 5 K.

Note that these kinds of calculations heavily depend on hardware memory, so that for more sizeable systems with larger number of particles, errors related to memory allocation could happen depending on user's hardware capacity.

